package com.rustcraft.registry;

import com.rustcraft.item.UpgradeChipItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Все предметы-улучшения. Всего 9 чипов: 3 системы x 3 уровня.
 * Имена: chip_vision_0, chip_vision_1, chip_vision_2, chip_memory_0 ... chip_scanner_2.
 * (Названия на русском — в assets/rustcraft/lang/ru_ru.json, картинки — в textures/item/.)
 */
public class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, "rustcraft");

    private static final String[] SYSTEMS = {"vision", "memory", "scanner"};

    /** Список всех чипов — по нему вкладка креатива сама заполняется. */
    public static final List<RegistryObject<Item>> CHIPS = new ArrayList<>();

    static {
        for (int system = 0; system < SYSTEMS.length; system++) {
            for (int level = 0; level <= 2; level++) {
                final int s = system, l = level;
                CHIPS.add(ITEMS.register("chip_" + SYSTEMS[s] + "_" + l, () -> new UpgradeChipItem(s, l)));
            }
        }
    }
}
