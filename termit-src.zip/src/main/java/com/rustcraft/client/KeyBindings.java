package com.rustcraft.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

/**
 * Клавиша P. Появляется в настройках: Управление -> "RustCraft".
 * (Если P уже занята другой кнопкой — её можно переназначить там же.)
 */
@Mod.EventBusSubscriber(modid = "rustcraft", bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class KeyBindings {
    public static final KeyMapping TERMINATOR_KEY = new KeyMapping(
            "key.rustcraft.terminator",             // название кнопки (см. lang)
            InputConstants.Type.KEYSYM,
            GLFW.GLFW_KEY_P,                        // <-- сама клавиша P
            "key.categories.rustcraft");            // раздел в настройках

    @SubscribeEvent
    public static void register(RegisterKeyMappingsEvent e) {
        e.register(TERMINATOR_KEY);
    }
}
