package com.rustcraft.client;

import com.mojang.blaze3d.shaders.FogShape;
import com.rustcraft.common.ClientState;
import com.rustcraft.net.ActionPacket;
import com.rustcraft.net.NetworkHandler;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.client.event.RenderGuiEvent;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * Клиент: клавиша P, туман/затемнение (Зрение), линия и подсветка игроков (Сканер).
 * Индекс в массивах ниже = уровень системы (0 повреждён, 1 средний, 2 максимальный).
 */
@Mod.EventBusSubscriber(modid = "rustcraft", value = Dist.CLIENT)
public class ClientEvents {
    // Сканер: как часто бежит линия / подсвечиваются игроки, на сколько тиков, и радиус.
    private static final int[] LINE_INTERVAL = {100, 60, 40};
    private static final int[] HL_INTERVAL = {100, 60, 20};
    private static final int[] HL_DURATION = {40, 40, 30};
    private static final double[] RADIUS = {16.0, 32.0, 48.0};
    private static final int LINE_SWEEP_TICKS = 20;

    private static int tick = 0;
    private static int lineStart = -1000;
    private static boolean shaderOn = false;
    private static LocalPlayer lastPlayer = null;
    /** id игрока -> тик, когда подсветку надо выключить. */
    private static final Map<Integer, Integer> highlighted = new HashMap<>();

    // ---------- Клавиша P ----------
    private static void handleKey(Minecraft mc) {
        while (KeyBindings.TERMINATOR_KEY.consumeClick()) {
            if (mc.player == null || mc.screen != null) continue;   // только в игре, не поверх других окон
            if (!ClientState.active) {
                // Ещё человек -> P делает тебя терминатором (навсегда)
                NetworkHandler.CHANNEL.sendToServer(new ActionPacket(ActionPacket.ACTIVATE, 0));
            } else {
                // Уже терминатор -> P открывает слоты улучшений
                mc.setScreen(new UpgradeScreen());
            }
        }
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        handleKey(mc);

        // Нет мира — всё сбрасываем
        if (mc.player == null || mc.level == null) {
            shaderOn = false;
            highlighted.clear();
            lastPlayer = null;
            return;
        }
        if (mc.player != lastPlayer) { // новый игрок (респавн/смена мира)
            lastPlayer = mc.player;
            shaderOn = false;
            highlighted.clear();
        }
        tick++;

        // Зрение "повреждён": чёрно-белый экран
        boolean wantShader = ClientState.active && ClientState.vision == 0;
        if (wantShader && !shaderOn) {
            mc.gameRenderer.loadEffect(new ResourceLocation("shaders/post/desaturate.json"));
            shaderOn = true;
        } else if (!wantShader && shaderOn) {
            mc.gameRenderer.shutdownEffect();
            shaderOn = false;
        }

        if (ClientState.active) {
            int s = ClientState.scanner;
            if (tick % LINE_INTERVAL[s] == 0) lineStart = tick;          // запускаем бегущую линию
            if (tick % HL_INTERVAL[s] == 0) {                            // подсвечиваем ближних игроков
                double r2 = RADIUS[s] * RADIUS[s];
                for (AbstractClientPlayer other : mc.level.players()) {
                    if (other == mc.player) continue;
                    if (mc.player.distanceToSqr(other) <= r2) {
                        highlighted.put(other.getId(), tick + HL_DURATION[s]);
                    }
                }
            }
        } else if (!highlighted.isEmpty()) {                             // перестали быть терминатором — гасим подсветку
            for (Integer id : highlighted.keySet()) setGlow(mc, id, false);
            highlighted.clear();
        }

        // Выключаем подсветку, когда вышло время
        Iterator<Map.Entry<Integer, Integer>> it = highlighted.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Integer, Integer> en = it.next();
            if (en.getValue() <= tick) {
                setGlow(mc, en.getKey(), false);
                it.remove();
            } else {
                setGlow(mc, en.getKey(), true);
            }
        }
    }

    private static void setGlow(Minecraft mc, int id, boolean glow) {
        if (mc.level == null) return;
        Entity ent = mc.level.getEntity(id);
        if (ent != null) ent.setGlowingTag(glow);
    }

    // ---------- Зрение: туман и затемнение (уровни 0 и 1) ----------
    @SubscribeEvent
    public static void onFog(ViewportEvent.RenderFog e) {
        if (!ClientState.active || ClientState.vision >= 2) return;
        float far = ClientState.vision == 0 ? 6.0f : 24.0f;
        e.setNearPlaneDistance(0f);
        e.setFarPlaneDistance(far);
        e.setFogShape(FogShape.SPHERE);
        e.setCanceled(true);
    }

    @SubscribeEvent
    public static void onFogColor(ViewportEvent.ComputeFogColor e) {
        if (!ClientState.active || ClientState.vision >= 2) return;
        e.setRed(0f);
        e.setGreen(0f);
        e.setBlue(0f);
    }

    @SubscribeEvent
    public static void onGuiPre(RenderGuiEvent.Pre e) {
        if (!ClientState.active || ClientState.vision >= 2) return;
        GuiGraphics g = e.getGuiGraphics();
        g.fill(0, 0, e.getWindow().getGuiScaledWidth(), e.getWindow().getGuiScaledHeight(), 0x38000000);
    }

    // ---------- Сканер: бегущая линия сверху вниз ----------
    @SubscribeEvent
    public static void onGuiPost(RenderGuiEvent.Post e) {
        if (!ClientState.active) return;
        float t = (tick - lineStart) + e.getPartialTick();
        if (t < 0 || t >= LINE_SWEEP_TICKS) return;
        int w = e.getWindow().getGuiScaledWidth();
        int h = e.getWindow().getGuiScaledHeight();
        int y = (int) (t / LINE_SWEEP_TICKS * h);
        GuiGraphics g = e.getGuiGraphics();
        g.fill(0, y - 10, w, y - 5, 0x18FFFFFF);
        g.fill(0, y - 5, w, y - 2, 0x40FFFFFF);
        g.fill(0, y - 2, w, y + 2, 0xFFFFFFFF);
    }

    @SubscribeEvent
    public static void onLogout(ClientPlayerNetworkEvent.LoggingOut e) {
        ClientState.reset();
        highlighted.clear();
        shaderOn = false;
    }
}
